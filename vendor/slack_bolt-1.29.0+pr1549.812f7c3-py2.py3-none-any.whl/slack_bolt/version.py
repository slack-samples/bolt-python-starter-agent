"""Check the latest version at https://pypi.org/project/slack-bolt/"""

__version__ = "1.29.0+pr1549.812f7c3"
